print("""
My name is Dhanya Reddy.
I am pursuing a Bachelor's degree in Computer and Information Sciences.
I enjoy programming and exploring new technologies.
In my free time, I like reading and learning about data analytics.
""")