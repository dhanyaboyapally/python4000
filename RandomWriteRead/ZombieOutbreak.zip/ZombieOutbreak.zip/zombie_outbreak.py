# Prompt user for inputs
initial_infected = float(input("Enter the initial number of infected (Day 0): "))
daily_rate = float(input("Enter the daily infection rate (in %): "))
days = float(input("Enter the number of days to simulate: "))

growth_factor = 1 + (daily_rate / 100)
total_infected = initial_infected * (growth_factor ** days)
rounded_total = round(total_infected)


if days.is_integer():
    days_display = int(days)
else:
    days_display = days

# Output the result
print(f"After {days_display} days, the total number of infected is approximately {rounded_total}.")
